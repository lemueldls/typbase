import type { NodeOAuthClient, NodeSavedSessionStore, NodeSavedStateStore, OAuthClientMetadataInput, OAuthSession, RuntimeLock } from '@atproto/oauth-client-node'
import type { ClientMetadataOptions } from './oauth/metadata.ts'
import type { DidString } from './types.ts'
import { clientMetadata as buildClientMetadata } from './oauth/metadata.ts'
import { consentScope } from './oauth/scope.ts'

export type { ClientMetadataOptions } from './oauth/metadata.ts'
export { spacesSupported } from './supported.ts'
export type { DidString } from './types.ts'
export type { NodeSavedSession, NodeSavedSessionStore, NodeSavedState, NodeSavedStateStore, OAuthSession, RuntimeLock } from '@atproto/oauth-client-node'

export interface OAuthOptions extends ClientMetadataOptions {
  stores: {
    /** In-flight authorizations. Defaults to memory. */
    state?: NodeSavedStateStore
    /** Sessions keyed by DID. */
    session: NodeSavedSessionStore
  }
  /** Allow `http:` authorization servers, for a local PDS. */
  allowHttp?: boolean
  /** Where handles resolve, when DNS and `.well-known` cannot answer. A local PDS serves `resolveHandle`. */
  handleResolver?: string | URL
  /** Defaults to `https://plc.directory`. A local PDS runs its own. */
  plcDirectoryUrl?: string | URL
  /** Serialises token refreshes per DID. Several instances need one they share. */
  requestLock?: RuntimeLock
}

export interface OAuth {
  /** Serve at `metadataPath`. */
  readonly metadata: OAuthClientMetadataInput
  readonly client: NodeOAuthClient
  /** URL to redirect the user to. `scopes` must be a subset of the client's. */
  authorize: (identifier: string, options?: { state?: string, scopes?: readonly string[] }) => Promise<URL>
  /** The session works as `createAirspace({ session })`, and `did` as `createAirspace({ identity: { did } })`. */
  callback: (params: URLSearchParams) => Promise<{ session: OAuthSession, did: DidString, state: string | null }>
  restore: (did: string) => Promise<OAuthSession>
  revoke: (did: string) => Promise<void>
}

/** Metadata for a public, DPoP-bound client. Loopback origins encode it into the `client_id`. */
export function clientMetadata(options: ClientMetadataOptions): OAuthClientMetadataInput {
  return buildClientMetadata(options) as OAuthClientMetadataInput
}

function memoryStore<T>(): { get: (k: string) => Promise<T | undefined>, set: (k: string, v: T) => Promise<void>, del: (k: string) => Promise<void> } {
  const map = new Map<string, T>()
  return {
    async get(k) { return map.get(k) },
    async set(k, v) { map.set(k, v) },
    async del(k) { map.delete(k) },
  }
}

// Imported lazily: loading `@atproto/oauth-client-node` swaps Node's global undici dispatcher.
export async function createOAuth(options: OAuthOptions): Promise<OAuth> {
  const { NodeOAuthClient } = await import('@atproto/oauth-client-node')
  const metadata = clientMetadata(options)
  const client = new NodeOAuthClient({
    clientMetadata: metadata,
    stateStore: options.stores.state ?? memoryStore(),
    sessionStore: options.stores.session,
    requestLock: options.requestLock,
    allowHttp: options.allowHttp,
    ...(options.handleResolver ? { handleResolver: options.handleResolver } : {}),
    ...(options.plcDirectoryUrl ? { plcDirectoryUrl: options.plcDirectoryUrl } : {}),
  })
  return {
    metadata,
    client,
    async authorize(identifier, opts) {
      const scope = consentScope(options.scopes, opts?.scopes, metadata.scope)
      return client.authorize(identifier, { scope, state: opts?.state })
    },
    async callback(params) {
      const { session, state } = await client.callback(params)
      return { session, did: session.did, state }
    },
    restore: did => client.restore(did),
    revoke: did => client.revoke(did),
  }
}
